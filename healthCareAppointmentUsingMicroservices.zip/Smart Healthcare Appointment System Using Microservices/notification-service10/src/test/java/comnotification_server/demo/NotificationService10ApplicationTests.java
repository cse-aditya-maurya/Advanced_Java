package comnotification_server.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationService10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
