package comnotification_server.demo.listener;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import comnotification_server.demo.event.AppointmentEvent;


@Component
public class AppointmentListener {

    @RabbitListener(queues = "appointment-queue")
    public void receive(AppointmentEvent event) {

        System.out.println("🔥 NOTIFICATION SERVICE RECEIVED EVENT 🔥");

        System.out.println("Appointment Id: " + event.getAppointmentId());
        System.out.println("Doctor Id: " + event.getDoctorId());
        System.out.println("Patient: " + event.getPatientName());

    }
}