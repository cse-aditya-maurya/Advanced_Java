package comnotification_server.demo.event;


import lombok.Data;

@Data
public class AppointmentEvent {

    private int appointmentId;
    private int doctorId;
    private String patientName;

}