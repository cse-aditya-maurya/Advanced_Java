package com.healthcare.doctorservice10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorService10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
