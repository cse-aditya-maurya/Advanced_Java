package com.healthcare.doctorservice10.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.doctorservice10.entity.Doctor;
import com.healthcare.doctorservice10.repository.DoctorRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository repository;

    public Doctor save(Doctor doctor){
        return repository.save(doctor);
    }

    public List<Doctor> getAll(){
        return repository.findAll();
    }

    public Doctor getById(Long id){
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));
    }
}