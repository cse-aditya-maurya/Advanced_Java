package com.healthcare.doctorservice10.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.doctorservice10.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
}
