package com.apigateway.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateway10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
