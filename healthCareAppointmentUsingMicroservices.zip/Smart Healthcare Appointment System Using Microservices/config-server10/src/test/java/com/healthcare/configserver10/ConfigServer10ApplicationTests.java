package com.healthcare.configserver10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServer10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
