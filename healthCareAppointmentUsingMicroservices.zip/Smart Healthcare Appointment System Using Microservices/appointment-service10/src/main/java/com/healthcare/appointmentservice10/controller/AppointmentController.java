package com.healthcare.appointmentservice10.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.appointmentservice10.entity.Appointment;
import com.healthcare.appointmentservice10.repository.AppointmentRepository;
import com.healthcare.appointmentservice10.service.AppointmentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentService service;
    private final AppointmentRepository repo;

    public AppointmentController(AppointmentService service,
                                 AppointmentRepository repo) {
        this.service = service;
        this.repo = repo;
    }

    @PostMapping
    public Appointment create(@RequestBody Appointment a) {
        return service.createAppointment(a);
    }

    @GetMapping
    public List<Appointment> getAll() {
        return repo.findAll();
    }
}

