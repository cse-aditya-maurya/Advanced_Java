package com.healthcare.appointmentservice10.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;

@Configuration
public class RabbitConfig {

	 public static final String EXCHANGE = "appointment-exchange";
	    public static final String QUEUE = "appointment-queue";
	    public static final String ROUTING_KEY = "appointment-routing";

	    public RabbitConfig() {
	        System.out.println("⭐⭐⭐ RabbitConfig LOADED ⭐⭐⭐");
	    }

	    @Bean
	    public Queue queue() {
	        System.out.println("⭐⭐⭐ Queue Bean Created ⭐⭐⭐");
	        return new Queue(QUEUE);
	    }

	    @Bean
	    public DirectExchange exchange() {
	        System.out.println("⭐⭐⭐ Exchange Bean Created ⭐⭐⭐");
	        return new DirectExchange(EXCHANGE);
	    }

	    @Bean
	    public Binding binding(Queue queue, DirectExchange exchange) {
	        System.out.println("⭐⭐⭐ Binding Bean Created ⭐⭐⭐");
	        return BindingBuilder.bind(queue).to(exchange).with(ROUTING_KEY);
	    }
}