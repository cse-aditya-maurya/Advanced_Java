package com.healthcare.appointmentservice10.dto;

import lombok.Data;

@Data
public class Doctor {

    private Long id;
    private String name;
    private String specialization;
    private String hospital;
    private String availability;

//  /
}