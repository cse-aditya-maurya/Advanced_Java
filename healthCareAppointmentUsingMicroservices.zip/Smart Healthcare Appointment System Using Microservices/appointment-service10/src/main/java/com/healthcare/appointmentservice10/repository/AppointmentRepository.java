package com.healthcare.appointmentservice10.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.appointmentservice10.entity.Appointment;

public interface AppointmentRepository
extends JpaRepository<Appointment, Long> {
}