package com.healthcare.appointmentservice10.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.healthcare.appointmentservice10.dto.Doctor;

@FeignClient(name = "doctor-service10")
public interface DoctorClient {

    @GetMapping("/doctors/{id}")
    Doctor getDoctorById(@PathVariable("id") Long id);
}