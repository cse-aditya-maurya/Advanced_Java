package com.healthcare.appointmentservice10.service;

import java.util.List;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import com.healthcare.appointmentservice10.config.RabbitConfig;
import com.healthcare.appointmentservice10.dto.Doctor;
import com.healthcare.appointmentservice10.entity.Appointment;
import com.healthcare.appointmentservice10.event.AppointmentEvent;
import com.healthcare.appointmentservice10.feign.DoctorClient;
import com.healthcare.appointmentservice10.repository.AppointmentRepository;

@Service
public class AppointmentService {

    private final AppointmentRepository repository;
    private final DoctorClient doctorClient;
    private final RabbitTemplate rabbitTemplate;

    public AppointmentService(AppointmentRepository repository,
                              DoctorClient doctorClient,
                              RabbitTemplate rabbitTemplate) {
        this.repository = repository;
        this.doctorClient = doctorClient;
        this.rabbitTemplate = rabbitTemplate;
    }

    // ⭐ CREATE APPOINTMENT
    public Appointment createAppointment(Appointment appointment) {

        // ⭐ call doctor service (Feign)
        Doctor doctor = doctorClient.getDoctorById(appointment.getDoctorId());

        if (doctor == null) {
            throw new RuntimeException("Doctor not found");
        }

        // ⭐ save in DB
        Appointment saved = repository.save(appointment);

        // ⭐ publish RabbitMQ event
        AppointmentEvent event = new AppointmentEvent();
        event.setAppointmentId(saved.getId());
        event.setDoctorId(saved.getDoctorId());
        event.setPatientName(saved.getPatientName());

        rabbitTemplate.convertAndSend(
                RabbitConfig.EXCHANGE,
                RabbitConfig.ROUTING_KEY,
                event
        );

        return saved;
    }

    // ⭐ GET ALL
    public List<Appointment> getAllAppointments() {
        return repository.findAll();
    }
}