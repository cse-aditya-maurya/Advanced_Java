package com.healthcare.appointmentservice10.event;

import lombok.Data;

@Data
public class AppointmentEvent {

    private Long appointmentId;
    private String patientName;
    private Long doctorId;
	
  
}